import matplotlib.pyplot as plt


class EDA:

    def __init__(self, dataframe, output_dir):
        self.dataframe = dataframe
        self.output_dir = output_dir

    def print_summary(self):
        print("\nDataset Summary")
        print(f"Total Images  : {len(self.dataframe)}")
        print(f"Total Classes : {self.dataframe['label'].nunique()}")
        print(f"Mean Width    : {self.dataframe['width'].mean():.1f} px")
        print(f"Mean Height   : {self.dataframe['height'].mean():.1f} px")
        print(f"Classes       : {self.dataframe['label'].unique().tolist()}")

    def save_class_distribution(self):
        labels = self.dataframe["label"].value_counts().index.tolist()
        counts = self.dataframe["label"].value_counts().tolist()

        plt.figure(figsize=(10, 6))
        plt.bar(labels, counts, color="green")
        plt.title("Macroinvertebrate Images per Class")
        plt.xlabel("Species")
        plt.ylabel("Number of Images")
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig(f"{self.output_dir}/class_distribution.png")
        plt.close()

    def save_image_size_distribution(self):
        plt.figure(figsize=(12, 5))
        plt.subplot(1, 2, 1)
        plt.hist(self.dataframe["width"].tolist(), bins=20, color="darkblue")
        plt.title("Image Width Distribution")
        plt.xlabel("Width (px)")
        plt.ylabel("Count")
        plt.subplot(1, 2, 2)
        plt.hist(self.dataframe["height"].tolist(), bins=20, color="mediumpurple")
        plt.title("Image Height Distribution")
        plt.xlabel("Height (px)")
        plt.ylabel("Count")
        plt.tight_layout()
        plt.savefig(f"{self.output_dir}/image_size_distribution.png")
        plt.close()

    def save_sample_grid(self, train_dataset, class_names):
        plt.figure(figsize=(10, 10))
        for images_batch, labels_batch in train_dataset.take(1):
            for i in range(9):
                ax = plt.subplot(3, 3, i + 1)
                plt.imshow(images_batch[i].numpy().astype("uint8"))
                plt.title(class_names[labels_batch[i]])
                plt.axis("off")
        plt.suptitle("Sample Macroinvertebrate Images", fontsize=16)
        plt.tight_layout()
        plt.savefig(f"{self.output_dir}/sample_grid.png")
        plt.close()