import os
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.preprocessing import image


class Predictions:

    def __init__(self, model, class_names, test_folder, image_size, output_dir):
        self.model = model
        self.class_names = class_names
        self.test_folder = test_folder
        self.image_size = image_size
        self.output_dir = output_dir

    def predict_all(self):
        print("\nRunning Predictions on Images")

        img_files = [f for f in os.listdir(self.test_folder) if f.lower().endswith((".jpg", ".jpeg", ".png"))]

        if not img_files:
            print(f"No images found in '{self.test_folder}'. Please add some test images and rerun.")
            return

        fig, axes = plt.subplots(1, len(img_files), figsize=(5 * len(img_files), 6))

        if len(img_files) == 1:
            axes = [axes]

        for i, img_file in enumerate(img_files):
            path = os.path.join(self.test_folder, img_file)
            img = image.load_img(path, target_size=self.image_size)
            img_array = image.img_to_array(img)
            img_array = np.expand_dims(img_array, axis=0)
            preds = self.model.predict(img_array)
            pred_idx = np.argmax(preds[0])
            confidence = preds[0][pred_idx]

            print(f"Image: {img_file} --> Predicted: {self.class_names[pred_idx]} ({confidence * 100:.2f}%)")

            axes[i].imshow(image.load_img(path))
            axes[i].axis("off")
            axes[i].set_title(f"{self.class_names[pred_idx]}\n{confidence * 100:.2f}%", fontsize=12)

        plt.suptitle("Predictions on Test Images", fontsize=16)
        plt.tight_layout()
        plt.savefig(f"{self.output_dir}/all_predictions.png")
        plt.show()