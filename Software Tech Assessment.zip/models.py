import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, precision_recall_fscore_support


class Models:

    def __init__(self, model, train_dataset, val_dataset, class_names, training_rounds, output_dir, saved_model_path):
        self.model = model
        self.train_dataset = train_dataset
        self.val_dataset = val_dataset
        self.class_names = class_names
        self.training_rounds = training_rounds
        self.output_dir = output_dir
        self.saved_model_path = saved_model_path
        self.history = None

    def train(self):
        print(f"\nTraining for {self.training_rounds} epochs with batch size 16")
        self.history = self.model.fit(
            self.train_dataset,
            validation_data=self.val_dataset,
            epochs=self.training_rounds
        )

    def save_training_charts(self):
        acc = self.history.history["accuracy"]
        val_acc = self.history.history["val_accuracy"]
        loss = self.history.history["loss"]
        val_loss = self.history.history["val_loss"]
        epochs_range = range(self.training_rounds)

        plt.figure(figsize=(12, 5))
        plt.subplot(1, 2, 1)
        plt.plot(epochs_range, acc, label="Training Accuracy", color="cornflowerblue")
        plt.plot(epochs_range, val_acc, label="Validation Accuracy", color="mediumseagreen")
        plt.legend()
        plt.title("Training and Validation Accuracy")
        plt.subplot(1, 2, 2)
        plt.plot(epochs_range, loss, label="Training Loss", color="tomato")
        plt.plot(epochs_range, val_loss, label="Validation Loss", color="mediumpurple")
        plt.legend()
        plt.title("Training and Validation Loss")
        plt.tight_layout()
        plt.savefig(f"{self.output_dir}/training_charts.png")
        plt.close()

    def evaluate(self):
        val_loss_score, val_acc_score = self.model.evaluate(self.val_dataset)
        print(f"Validation Accuracy: {val_acc_score * 100:.2f}%")

    def save_confusion_matrix(self):
        y_true = []
        y_pred = []

        for images_batch, labels_batch in self.val_dataset:
            preds = self.model.predict(images_batch)
            y_true.extend(labels_batch.numpy())
            y_pred.extend(np.argmax(preds, axis=1))

        y_true = np.array(y_true)
        y_pred = np.array(y_pred)

        cm = confusion_matrix(y_true, y_pred)
        disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=self.class_names)
        plt.figure(figsize=(12, 12))
        disp.plot(cmap=plt.cm.Greens, xticks_rotation="vertical")
        plt.title("Confusion Matrix on Validation Set")
        plt.tight_layout()
        plt.savefig(f"{self.output_dir}/confusion_matrix.png")
        plt.close()

        precision, recall, f1, _ = precision_recall_fscore_support(
            y_true, y_pred, average="weighted"
        )
        print(f"Weighted Precision : {precision:.4f}")
        print(f"Weighted Recall    : {recall:.4f}")
        print(f"Weighted F1-score  : {f1:.4f}")

    def save_model(self):
        self.model.save(self.saved_model_path)
        print(f"Model saved to {self.saved_model_path}")