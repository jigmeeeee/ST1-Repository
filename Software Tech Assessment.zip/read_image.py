import os
import cv2
import pandas as pd


class ReadImage:

    def __init__(self, image_folder):
        self.image_folder = image_folder
        self.supported = {".jpg", ".jpeg", ".png", ".bmp"}

    def build(self):
        records = []

        for root, dirs, files in os.walk(self.image_folder):
            for file in files:
                if os.path.splitext(file)[1].lower() in self.supported:
                    file_path = os.path.join(root, file)
                    img = cv2.imread(file_path)
                    if img is None:
                        continue
                    height, width = img.shape[:2]
                    channels = img.shape[2] if len(img.shape) == 3 else 1
                    label = os.path.basename(root)
                    records.append({
                        "file_path": file_path,
                        "label": label,
                        "width": width,
                        "height": height,
                        "channels": channels
                    })

        return pd.DataFrame(records)
