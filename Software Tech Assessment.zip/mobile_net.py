import tensorflow as tf
from tensorflow.keras import layers, models


class MobileNetV2:

    def __init__(self, image_size, num_classes):
        self.image_size = image_size
        self.num_classes = num_classes
        self.model = None

    def build(self):
        augmentation_pipeline = tf.keras.Sequential([
            layers.RandomFlip("horizontal"),
            layers.RandomRotation(0.1),
            layers.RandomZoom(0.1),
        ])

        base_model = tf.keras.applications.MobileNetV2(
            input_shape=self.image_size + (3,),
            include_top=False,
            weights="imagenet"
        )
        base_model.trainable = False

        inputs = layers.Input(shape=self.image_size + (3,))
        x = augmentation_pipeline(inputs)
        x = tf.keras.applications.mobilenet_v2.preprocess_input(x)
        x = base_model(x, training=False)
        x = layers.GlobalAveragePooling2D()(x)
        x = layers.Dense(64, activation="relu")(x)
        x = layers.Dropout(0.2)(x)
        outputs = layers.Dense(self.num_classes, activation="softmax")(x)

        self.model = models.Model(inputs, outputs)
        self.model.compile(
            optimizer="adam",
            loss="sparse_categorical_crossentropy",
            metrics=["accuracy"]
        )
        self.model.summary()
        return self.model
