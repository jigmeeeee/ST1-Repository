import os
import tensorflow as tf

from read_image import ReadImage
from eda import EDA
from mobile_net import MobileNetV2
from models import Models
from predictions import Predictions


class Pipeline:

    def __init__(self):
        self.image_folder = "datasets/insects"
        self.test_folder = "datasets/code_test"
        self.output_dir = "outputs"
        self.saved_model_path = "outputs/insect_savefile.keras"
        self.image_size = (224, 224)
        self.batch = 16
        self.seed = 123
        self.training_rounds = 15

    def run(self):
        os.makedirs(self.output_dir, exist_ok=True)
        os.makedirs(self.test_folder, exist_ok=True)

        print("Stage 1: Performing Exploratory Data Analysis (EDA)")

        reader = ReadImage(self.image_folder)
        dataframe = reader.build()

        eda = EDA(dataframe, self.output_dir)
        eda.print_summary()
        eda.save_class_distribution()
        eda.save_image_size_distribution()

        print("\nStage 2: Performing Classification")
        print("Loading dataset with 80/20 train-validation split")

        train_dataset = tf.keras.preprocessing.image_dataset_from_directory(
            self.image_folder,
            validation_split=0.2,
            subset="training",
            seed=self.seed,
            image_size=self.image_size,
            batch_size=self.batch
        )

        val_dataset = tf.keras.preprocessing.image_dataset_from_directory(
            self.image_folder,
            validation_split=0.2,
            subset="validation",
            seed=self.seed,
            image_size=self.image_size,
            batch_size=self.batch
        )

        class_names = train_dataset.class_names
        num_classes = len(class_names)
        print(f"Classes found: {class_names}")

        AUTOTUNE = tf.data.AUTOTUNE
        train_dataset = train_dataset.prefetch(buffer_size=AUTOTUNE)
        val_dataset = val_dataset.prefetch(buffer_size=AUTOTUNE)

        eda.save_sample_grid(train_dataset, class_names)

        print("\nBuilding model with MobileNetV2 base")

        builder = MobileNetV2(self.image_size, num_classes)
        model = builder.build()

        classifier = Models(
            model, train_dataset, val_dataset,
            class_names, self.training_rounds,
            self.output_dir, self.saved_model_path
        )
        classifier.train()
        classifier.save_training_charts()
        classifier.evaluate()
        classifier.save_confusion_matrix()
        classifier.save_model()

        predictor = Predictions(model, class_names, self.test_folder, self.image_size, self.output_dir)
        predictor.predict_all()
